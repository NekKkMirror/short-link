--
-- PostgreSQL database dump
--

-- Dumped from database version 13.18 (Debian 13.18-1.pgdg120+1)
-- Dumped by pg_dump version 16.6 (Ubuntu 16.6-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

\connect test

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER SCHEMA public OWNER TO test;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: analytics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics (
    id text NOT NULL,
    "linkId" text NOT NULL,
    "ipAddress" text NOT NULL,
    "clickedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.analytics OWNER TO test;

--
-- Name: shortened_links; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shortened_links (
    id text NOT NULL,
    "shortUrl" text NOT NULL,
    "originalUrl" text NOT NULL,
    alias text,
    "clickCount" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone
);


ALTER TABLE public.shortened_links OWNER TO test;

--
-- Data for Name: analytics; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.analytics VALUES ('beadc700-6342-401b-ba1e-4d15b3bb35ac', 'beadc700-6342-401b-ba1e-4d15b3bb35ac', '62.247.250.87', '2025-01-09 18:11:02');
INSERT INTO public.analytics VALUES ('beadc750-6342-401b-ba1e-4d15b3bb35ac', 'beadc700-6342-401b-ba1e-4d15b3bb35ac', '62.247.250.87', '2025-01-09 18:11:14');
INSERT INTO public.analytics VALUES ('beadc705-6342-401b-ba1e-4d15b3bb35ac', 'beadc700-6342-401b-ba1e-4d15b3bb35ac', '62.247.250.87', '2025-01-09 18:11:13');
INSERT INTO public.analytics VALUES ('beadc710-6342-401b-ba1e-4d15b3bb35ac', 'beadc700-6342-401b-ba1e-4d15b3bb35ac', '62.247.250.87', '2025-01-09 18:11:04');
INSERT INTO public.analytics VALUES ('beadc702-6342-401b-ba1e-4d15b3bb35ac', 'beadc700-6342-401b-ba1e-4d15b3bb35ac', '62.247.250.87', '2025-01-09 18:11:05');
INSERT INTO public.analytics VALUES ('beadc730-6342-401b-ba1e-4d15b3bb35ac', 'beadc700-6342-401b-ba1e-4d15b3bb35ac', '62.247.250.87', '2025-01-09 18:11:08');
INSERT INTO public.analytics VALUES ('beadc703-6342-401b-ba1e-4d15b3bb35ac', 'beadc700-6342-401b-ba1e-4d15b3bb35ac', '62.247.250.87', '2025-01-09 18:11:07');
INSERT INTO public.analytics VALUES ('beadc706-6342-401b-ba1e-4d15b3bb35ac', 'beadc700-6342-401b-ba1e-4d15b3bb35ac', '62.247.250.87', '2025-01-09 18:11:15');
INSERT INTO public.analytics VALUES ('beadc701-6342-401b-ba1e-4d15b3bb35ac', 'beadc700-6342-401b-ba1e-4d15b3bb35ac', '62.247.250.87', '2025-01-09 18:11:03');
INSERT INTO public.analytics VALUES ('beadc740-6342-401b-ba1e-4d15b3bb35ac', 'beadc700-6342-401b-ba1e-4d15b3bb35ac', '62.247.250.87', '2025-01-09 18:11:12');
INSERT INTO public.analytics VALUES ('beadc720-6342-401b-ba1e-4d15b3bb35ac', 'beadc700-6342-401b-ba1e-4d15b3bb35ac', '62.247.250.87', '2025-01-09 18:11:06');
INSERT INTO public.analytics VALUES ('beadc704-6342-401b-ba1e-4d15b3bb35ac', 'beadc700-6342-401b-ba1e-4d15b3bb35ac', '62.247.250.87', '2025-01-09 18:11:09');
INSERT INTO public.analytics VALUES ('beadc700-6532-401b-ba1e-4d15b3bb35ac', 'c9cdfd11-f3ec-498e-a3bf-4bfb34d1b4f5', '62.247.250.87', '2025-01-09 18:11:02');
INSERT INTO public.analytics VALUES ('beadc700-6712-401b-ba1e-4d15b3bb35ac', 'c9cdfd11-f3ec-498e-a3bf-4bfb34d1b4f5', '62.247.250.87', '2025-01-09 18:11:02');


--
-- Data for Name: shortegned_links; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.shortened_links VALUES ('c9cdfd11-f3ec-498e-a3bf-4bfb34d1b4f5', 'yub', 'https://www.youtube.com/', 'yub', 2, '2025-01-09 17:51:18', NULL);
INSERT INTO public.shortened_links VALUES ('beadc700-6342-401b-ba1e-4d15b3bb35ac', 'ges3y2', 'https://www.uuidgenerator.net', 'ges3y2', 12, '2025-01-10 17:52:13', NULL);


--
-- Name: analytics analytics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics
    ADD CONSTRAINT analytics_pkey PRIMARY KEY (id);


--
-- Name: shortened_links shortened_links_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shortened_links
    ADD CONSTRAINT shortened_links_pkey PRIMARY KEY (id);


--
-- Name: shortened_links_alias_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX shortened_links_alias_key ON public.shortened_links USING btree (alias);


--
-- Name: shortened_links_shortUrl_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "shortened_links_shortUrl_key" ON public.shortened_links USING btree ("shortUrl");


--
-- Name: analytics analytics_linkId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics
    ADD CONSTRAINT "analytics_linkId_fkey" FOREIGN KEY ("linkId") REFERENCES public.shortened_links(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

